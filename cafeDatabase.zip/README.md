# cafeDatabase
some IT support of cafe processes (made on C# in VS  for fun and study)

CafeDatabaseApplication folder contains desktop (Windows) application written in VS2017 on C#.

INITIAL_DATA sql file contains T-SQL statements to create tables and insert some test data.  